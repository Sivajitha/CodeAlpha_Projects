document.addEventListener('DOMContentLoaded', function() {
    // Lightbox functionality
    const galleryItems = document.querySelectorAll('.gallery-item');
    const lightbox = document.querySelector('.lightbox');
    const lightboxImg = document.querySelector('.lightbox-img');
    const closeBtn = document.querySelector('.close-btn');
    const prevBtn = document.querySelector('.prev');
    const nextBtn = document.querySelector('.next');
    const captionTitle = document.querySelector('.caption-title');
    const captionText = document.querySelector('.caption-text');
    const filterButtons = document.querySelectorAll('.filter-btn');

    let currentImageIndex = 0;
    const images = Array.from(galleryItems);

    // Open lightbox
    galleryItems.forEach((item, index) => {
        item.addEventListener('click', () => {
            currentImageIndex = index;
            updateLightbox();
            lightbox.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
    });

    // Update lightbox content
    function updateLightbox() {
        const imgSrc = images[currentImageIndex].querySelector('.gallery-img').src;
        const imgAlt = images[currentImageIndex].querySelector('.gallery-img').alt;
        const caption = images[currentImageIndex].querySelector('.gallery-caption h3').textContent;
        const desc = images[currentImageIndex].querySelector('.gallery-caption p').textContent;

        lightboxImg.src = imgSrc;
        lightboxImg.alt = imgAlt;
        captionTitle.textContent = caption;
        captionText.textContent = desc;
    }

    // Close lightbox
    closeBtn.addEventListener('click', () => {
        lightbox.classList.remove('active');
        document.body.style.overflow = 'auto';
    });

    // Navigate images
    prevBtn.addEventListener('click', () => {
        currentImageIndex = (currentImageIndex - 1 + images.length) % images.length;
        updateLightbox();
    });

    nextBtn.addEventListener('click', () => {
        currentImageIndex = (currentImageIndex + 1) % images.length;
        updateLightbox();
    });

    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (!lightbox.classList.contains('active')) return;

        if (e.key === 'Escape') {
            lightbox.classList.remove('active');
            document.body.style.overflow = 'auto';
        } else if (e.key === 'ArrowLeft') {
            currentImageIndex = (currentImageIndex - 1 + images.length) % images.length;
            updateLightbox();
        } else if (e.key === 'ArrowRight') {
            currentImageIndex = (currentImageIndex + 1) % images.length;
            updateLightbox();
        }
    });

    // Filter gallery
    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Update active button
            filterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            const filter = button.dataset.filter;
            
            galleryItems.forEach(item => {
                if (filter === 'all' || item.dataset.category === filter) {
                    item.style.display = 'block';
                    item.style.animation = 'fadeInUp 0.8s ease-out';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });

    // Parallax effect on gallery items
    window.addEventListener('mousemove', (e) => {
        const xPos = e.clientX / window.innerWidth;
        const yPos = e.clientY / window.innerHeight;
        
        galleryItems.forEach((item, index) => {
            const xOffset = (xPos - 0.5) * 20;
            const yOffset = (yPos - 0.5) * 20;
            const delay = index * 0.05;
            
            item.style.transform = `translateY(-10px) translateX(${xOffset}px) translateY(${yOffset}px) scale(1.03)`;
            item.style.transition = `transform 0.5s ease ${delay}s`;
        });
    });
});